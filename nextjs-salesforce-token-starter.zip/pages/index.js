export default function Home() {
  return (
    <main style={{ fontFamily: 'system-ui, sans-serif', padding: 40 }}>
      <h1>Next.js Salesforce Token Starter</h1>
      <p>Deploy this project to Vercel and visit <code>/api/token</code> to test the server-side token fetch.</p>
    </main>
  );
}
